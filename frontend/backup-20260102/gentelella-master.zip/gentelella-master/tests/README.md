# Test Directory

This directory contains secure test files for development purposes.
Test files should never contain hardcoded URLs or sensitive information.
