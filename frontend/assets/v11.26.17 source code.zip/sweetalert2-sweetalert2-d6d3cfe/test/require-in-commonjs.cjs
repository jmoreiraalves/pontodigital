require('../dist/sweetalert2.js')
require('../dist/sweetalert2.all.js')
